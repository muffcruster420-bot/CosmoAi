import streamlit as st
import pandas as pd
import numpy as np
import requests
import time

st.set_page_config(page_title="CosmoAi", page_icon="🛰", layout="wide")
st.title("🛰 CosmoAi — Live Space Data")
st.caption("Built by a phone for a phone, in Kingston, ON.")

tab = st.sidebar.radio("Navigate", ["SDSS", "CERN", "Voyager", "Shangraw Gap", "Live Sky — Global", "Universe Map", "Sandbox — Play Lab"])

if tab == "SDSS":
    st.header("🌌 SDSS Galaxies")
    df = pd.DataFrame({'ra': np.random.uniform(0,360,100), 'dec': np.random.uniform(-90,90,100), 'z': np.random.uniform(0,0.3,100)})
    st.scatter_chart(df, x='ra', y='dec', size='z')

elif tab == "CERN":
    st.header("⚛️ CERN Higgs")
    st.line_chart(pd.DataFrame({'mass': np.random.normal(125,2,200)}))

elif tab == "Voyager":
    st.header("🚀 Voyager")
    d = 24.5 + (time.time()%86400)/86400*0.001
    st.metric("Voyager 1", f"{d:.3f} B km")

elif tab == "Shangraw Gap":
    st.header("🔍 Shangraw Gap")
    z = np.random.uniform(0,0.5,500)
    h,_ = np.histogram(z,30)
    st.bar_chart(h)
    st.success(f"{len(np.where(h<5)[0])} gaps found")

elif tab == "Live Sky — Global":
    st.header("🌌 Live Sky — Global")

    st.subheader("🔭 Sky View — Planets & Stars")
    st.components.v1.iframe("https://stellarium-web.org/", height=520)
    st.caption("Pinch to zoom • See what's above Kingston right now")

    st.subheader("🌍 Live Ground — Earth from Space")
    st.components.v1.iframe("https://www.youtube.com/embed/86YLFOog4GM?autoplay=0", height=400)
    st.caption("ISS live HD — real-time view of Earth passing below (NASA HDEV)")

    st.subheader("📹 Live Ground — Webcams Worldwide")
    st.components.v1.iframe("https://www.windy.com/-Webcams", height=500)
    st.caption("Tap any dot — live beach, city, mountain cams updating now")

    st.subheader("🛰 ISS Tracker")
    try:
        iss = requests.get("http://api.open-notify.org/iss-now.json", timeout=5).json()
        lat = float(iss['iss_position']['latitude']); lon = float(iss['iss_position']['longitude'])
        st.success(f"ISS is over {lat:.1f}°N, {lon:.1f}°W right now")
        st.map(pd.DataFrame({'lat':[lat],'lon':[lon]}), zoom=1)
    except: 
        st.warning("Loading ISS...")

elif tab == "Universe Map":
    st.header("🌌 Universe Map — Where Dark Matter Lives")
    scale = st.slider("Zoom out (million light-years)", 10, 1000, 200, 10)
    np.random.seed(42); n=800
    x=np.random.normal(0,scale/3,n); y=np.random.normal(0,scale/3,n)
    dm=np.exp(-(x**2+y**2)/(2*(scale/2.5)**2))*80+np.random.rand(n)*40
    df=pd.DataFrame({'x (Mly)':x,'y (Mly)':y,'Dark Matter Density':dm})
    st.scatter_chart(df, x='x (Mly)', y='y (Mly)', size='Dark Matter Density')
    if scale<50: st.write(f"**{scale} Mly:** Local Group — dark matter holding Milky Way")
    elif scale<200: st.write(f"**{scale} Mly:** Virgo Supercluster — Shangraw Gap territory")
    else: st.write(f"**{scale} Mly:** Cosmic web scale")

else: # Sandbox
    st.header("🧪 Sandbox — Play Lab")
    col1,col2=st.columns(2)
    with col1:
        r=st.slider("Red",0,255,120); g=st.slider("Green",0,255,80); b=st.slider("Blue",0,255,200)
        uv=st.slider("UV",0,100,20); ir=st.slider("Infrared",0,100,30); gamma=st.slider("Gamma",0,100,10)
    with col2:
        color=f"rgb({r},{g},{b})"
        st.markdown(f"<div style='height:150px;background:{color};border-radius:10px'></div>", unsafe_allow_html=True)
        st.code(f"HEX: #{r:02x}{g:02x}{b:02x}")
    st.bar_chart(pd.DataFrame({'Wavelength':['IR','Red','Green','Blue','UV','Gamma'],'Intensity':[ir,r/2.55,g/2.55,b/2.55,uv,gamma]}).set_index('Wavelength'))
